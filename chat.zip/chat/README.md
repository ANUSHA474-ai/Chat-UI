# Real-time Chat App


1. Install dependencies:
